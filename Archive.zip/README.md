# react-portfolio

# Table of Contents

-[Description](#description)
-[Installation](#installation)
-[Usage](#usage)
-[Contribution](#contribution)
-[Test](#test)
-[Questions](#questions)

# Description:

* This is my react portolio. 

# Installation:

* Installation of react modules needed.

# Usage:

* Search through projects I have been a part of. 

# Contribution:

* Commit your update suggestions to GitHub for review and to be merged

# Test:

* None

* Click on the link below to view the live app.
-[Link to the live app](https://hectordiazjr.github.io/react-portfolio/)
*Click on the link below to view the Repo.
-[Link to the repo](https://github.com/HectorDiazJr/react-portfolio)

* Below are screen shots of the app.
![alt = screen shot of scheduler](public/assets/app.png)


# Questions:
Click on the link below to go to my GitHub page, for additional questions:
-[GitHub Portfolio](https:github.com/hectordiazjr)

Email me at hectordiaz1103@gmail.com with further questions